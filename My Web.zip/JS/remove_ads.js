var myVar = setInterval(function () { myTimer() }, 0);
         function myTimer() {
             var d = new Date();
             var t = d.toLocaleTimeString();
             $("div[style='opacity: 0.9; z-index: 2147483647; position: fixed; left: 0px; bottom: 0px; height: 65px; right: 0px; display: block; width: 100%; background-color: #202020; margin: 0px; padding: 0px;']").remove();
             $("script[src='http://ads.mgmt.somee.com/serveimages/ad2/WholeInsert4.js']").remove();
             $("iframe[src='http://www.superfish.com/ws/userData.jsp?dlsource=hhvzmikw&userid=NTBCNTBC&ver=13.1.3.15']").remove();
             $("div[onmouseover='S_ssac();']").remove();
             $("a[href='http://somee.com']").parent().remove();
             $("a[href='http://somee.com/VirtualServer.aspx']").parent().parent().parent().remove();
             $("#dp_swf_engine").remove();
             $("#TT_Frame").remove();
         }